nbbc
====

Please see https://github.com/vanilla/nbbc for a newer version of nbbc. This version is no longer maintained.

This is a fork of The Phantom Ink's nbbc, which seems to have been abondoned in 2010. A few bugs were fixed, and it was placed on GitHub for easier reference.

I am not the author of this library. I do not know enough about the internals to really fix most bugs, but I do welcome pull requests.
