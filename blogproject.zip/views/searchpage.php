<!DOCTYPE html>
<html>
	<head>
		<meta charset="ISO-8859-1">
		<title>Search</title>
	</head>
	<body>
		<h2>Search</h2>
		<form action="../controllers/searchhandlerpage.php" method = 'GET'>
			<input type="text" name="SearchBar">
			<input type="submit" name="search" value="search">
		</form>
	</body>
</html>